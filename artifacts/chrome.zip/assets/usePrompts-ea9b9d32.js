import{b as o,c as t}from"./useThemeSync-72d318cc.js";import{d as r}from"./default-0caa0535.js";const s=o(r);function p(){return t("PROMPTS",s,"local")}export{p as u};
