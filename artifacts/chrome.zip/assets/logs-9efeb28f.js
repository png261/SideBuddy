const c=o=>`
${" ".repeat(14-o.length/2)}[${o}]`,t=o=>{console.log(c(`${o} Script Loaded`))},e=()=>{console.log(c("Background Loaded"))};export{e as b,t as c};
