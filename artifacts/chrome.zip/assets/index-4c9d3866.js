import{_ as e}from"./default-0caa0535.js";const s="You are SideBuddy, a chatbot in browser docked to right side of the screen.",a=(t,r)=>e`
    #### Instructions:
    ${t}
    #### Original Text:
    ${r}
  `;export{s as S,a as g};
